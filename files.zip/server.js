// APSI battery-assistance backend: Node.js + Express + MongoDB (geospatial) + Socket.io
// Env: MONGO_URI, JWT_SECRET, OTP_SECRET, CORS_ORIGIN (comma separated), PORT
const express = require('express');
const http = require('http');
const crypto = require('crypto');
const mongoose = require('mongoose');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const INCENTIVE_RS = 50, RADIUS_M = 1000, MIN_HELPER_BATTERY = 20, PENDING_MS = 60000, OTP_TTL_MS = 20 * 60000, MAX_TRIES = 3;

/* ---------- 1. Schemas (GeoJSON coordinates are [longitude, latitude]) ---------- */
const pointDef = { type: { type: String, enum: ['Point'], default: 'Point' }, coordinates: { type: [Number], required: true } };

const Rider = mongoose.model('Rider', new mongoose.Schema({
  riderId: { type: String, unique: true, required: true },
  name: String,
  currentLocation: pointDef,
  status: { type: String, enum: ['idle', 'busy'], default: 'idle' },
  batteryLevel: { type: Number, min: 0, max: 100 },
  walletBalance: { type: Number, default: 0 },
  fcmToken: String
}).index({ currentLocation: '2dsphere' }).index({ status: 1 }));

const Station = mongoose.model('Station', new mongoose.Schema({
  stationId: { type: String, unique: true, required: true },
  name: String,
  location: pointDef,
  availableBatteries: { type: Number, default: 0 }
}).index({ location: '2dsphere' }));

const AssistanceRequest = mongoose.model('AssistanceRequest', new mongoose.Schema({
  requestId: { type: String, unique: true, required: true },
  victimRiderId: { type: String, required: true, index: true },
  helperRiderId: String,
  stationId: String,
  status: { type: String, enum: ['pending', 'accepted', 'completed', 'cancelled'], default: 'pending' },
  verificationOTP: String,            // HMAC of the code, never the plain 4 digits
  otpAttempts: { type: Number, default: 0 },
  declinedBy: [String],
  expiresAt: Date
}, { timestamps: true }));

/* ---------- App, auth, sockets ---------- */
const app = express();
app.use(express.json({ limit: '10kb' }));
// Production: add express-rate-limit on /api/sos/* and helmet().
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : false } });

const auth = (req, res, next) => {
  try { req.riderId = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET).riderId; next(); }
  catch (e) { res.status(401).json({ error: 'unauthorized' }); }
};
io.use((socket, next) => {                       // each rider app connects with its JWT
  try { socket.riderId = jwt.verify(socket.handshake.auth.token, process.env.JWT_SECRET).riderId; next(); }
  catch (e) { next(new Error('unauthorized')); }
});
io.on('connection', (socket) => socket.join('rider:' + socket.riderId));   // private room per rider
const notify = (riderId, event, payload) => io.to('rider:' + riderId).emit(event, payload);
async function sendPush(rider, title, body) { /* firebase-admin: admin.messaging().send({ token: rider.fcmToken, notification: { title, body } }) for when the app is in background */ }

const hashOtp = (requestId, otp) => crypto.createHmac('sha256', process.env.OTP_SECRET).update(requestId + ':' + otp).digest('hex');
const valid = (v) => typeof v === 'number' && isFinite(v);

/* ---------- 2. Matching: nearest station with stock within 1 km, then nearest idle rider to that station ---------- */
async function dispatch(reqDoc, station) {
  const helper = await Rider.findOneAndUpdate(
    { riderId: { $nin: [reqDoc.victimRiderId, ...reqDoc.declinedBy] }, status: 'idle', batteryLevel: { $gte: MIN_HELPER_BATTERY },
      currentLocation: { $near: { $geometry: station.location, $maxDistance: 5000 } } },   // $near sorts by distance, nearest first
    { $set: { status: 'busy' } }, { new: true });   // reserve atomically so two requests cannot grab the same rider
  if (!helper) { reqDoc.status = 'cancelled'; await reqDoc.save(); notify(reqDoc.victimRiderId, 'assist:cancelled', { requestId: reqDoc.requestId, reason: 'no_rider' }); return null; }
  reqDoc.helperRiderId = helper.riderId; await reqDoc.save();
  const payload = { requestId: reqDoc.requestId, station: { name: station.name, location: station.location }, incentive: INCENTIVE_RS, expiresInSec: PENDING_MS / 1000 };
  notify(helper.riderId, 'assist:request', payload);                       // in-app pop-up (Socket.io)
  sendPush(helper, 'Battery help needed', station.name + ' · reward Rs ' + INCENTIVE_RS);   // push if app is closed
  setTimeout(async () => {                                                  // no reply in 60 s: free helper, try the next one
    const r = await AssistanceRequest.findOne({ requestId: reqDoc.requestId, status: 'pending', helperRiderId: helper.riderId });
    if (r) { await Rider.updateOne({ riderId: helper.riderId }, { status: 'idle' }); r.declinedBy.push(helper.riderId); r.helperRiderId = undefined; await dispatch(r, station); }
  }, PENDING_MS);
  return helper;
}

app.post('/api/sos/trigger', auth, async (req, res) => {
  const { lng, lat } = req.body;
  if (!valid(lng) || !valid(lat) || Math.abs(lng) > 180 || Math.abs(lat) > 90) { return res.status(400).json({ error: 'bad_coordinates' }); }
  if (await AssistanceRequest.exists({ victimRiderId: req.riderId, status: { $in: ['pending', 'accepted'] } })) { return res.status(409).json({ error: 'request_already_open' }); }
  const station = await Station.findOne({
    availableBatteries: { $gt: 0 },
    location: { $near: { $geometry: { type: 'Point', coordinates: [lng, lat] }, $maxDistance: RADIUS_M } }
  });
  if (!station) { return res.status(404).json({ error: 'no_station_within_1km' }); }
  const requestId = 'REQ-' + crypto.randomBytes(5).toString('hex');
  const otp = String(crypto.randomInt(1000, 10000));                        // 4 digits, cryptographically random
  const reqDoc = await AssistanceRequest.create({ requestId, victimRiderId: req.riderId, stationId: station.stationId, verificationOTP: hashOtp(requestId, otp), expiresAt: new Date(Date.now() + OTP_TTL_MS) });
  const helper = await dispatch(reqDoc, station);
  if (!helper) { return res.status(404).json({ error: 'no_idle_rider' }); }
  // The OTP goes only to Rider A (this HTTP response). Rider B never receives it from the server.
  res.status(201).json({ requestId, station: { name: station.name, location: station.location }, helperName: helper.name, otp, qrPayload: requestId + '.' + otp });
});

/* ---------- 3. Rider B accepts / declines ---------- */
app.post('/api/sos/:requestId/respond', auth, async (req, res) => {
  const filter = { requestId: req.params.requestId, helperRiderId: req.riderId, status: 'pending' };
  if (req.body.accept === true) {
    const r = await AssistanceRequest.findOneAndUpdate(filter, { status: 'accepted' }, { new: true });
    if (!r) { return res.status(409).json({ error: 'not_pending' }); }
    notify(r.victimRiderId, 'assist:accepted', { requestId: r.requestId, helperName: (await Rider.findOne({ riderId: req.riderId })).name });
    return res.json({ status: 'accepted' });
  }
  const r = await AssistanceRequest.findOneAndUpdate(filter, { $push: { declinedBy: req.riderId }, $unset: { helperRiderId: 1 } }, { new: true });
  if (!r) { return res.status(409).json({ error: 'not_pending' }); }
  await Rider.updateOne({ riderId: req.riderId }, { status: 'idle' });
  await dispatch(r, await Station.findOne({ stationId: r.stationId }));
  res.json({ status: 'declined' });
});

/* ---------- 4. Rider B enters the OTP shown on Rider A's phone (or scans the QR) ---------- */
app.post('/api/sos/:requestId/verify', auth, async (req, res) => {
  const r = await AssistanceRequest.findOne({ requestId: req.params.requestId, helperRiderId: req.riderId, status: 'accepted' });
  if (!r || r.expiresAt < new Date()) { return res.status(409).json({ error: 'not_active' }); }
  const given = Buffer.from(hashOtp(r.requestId, String(req.body.otp || '')));
  const real = Buffer.from(r.verificationOTP);
  if (!crypto.timingSafeEqual(given, real)) {
    const upd = await AssistanceRequest.findOneAndUpdate({ _id: r._id, status: 'accepted' }, { $inc: { otpAttempts: 1 } }, { new: true });
    if (upd.otpAttempts >= MAX_TRIES) {                                     // lock after 3 wrong tries
      await AssistanceRequest.updateOne({ _id: r._id }, { status: 'cancelled' });
      await Rider.updateOne({ riderId: req.riderId }, { status: 'idle' });
      notify(r.victimRiderId, 'assist:cancelled', { requestId: r.requestId, reason: 'too_many_attempts' });
      return res.status(423).json({ error: 'locked' });
    }
    return res.status(401).json({ error: 'wrong_otp', triesLeft: MAX_TRIES - upd.otpAttempts });
  }
  const done = await AssistanceRequest.findOneAndUpdate({ _id: r._id, status: 'accepted' }, { status: 'completed' }, { new: true });   // only one verify can win
  if (!done) { return res.status(409).json({ error: 'already_done' }); }
  await Station.updateOne({ stationId: r.stationId, availableBatteries: { $gt: 0 } }, { $inc: { availableBatteries: -1 } });
  await Rider.updateOne({ riderId: req.riderId }, { status: 'idle', $inc: { walletBalance: INCENTIVE_RS } });   // unlock cash incentive
  notify(r.victimRiderId, 'assist:completed', { requestId: r.requestId });
  notify(req.riderId, 'assist:incentive', { requestId: r.requestId, amount: INCENTIVE_RS });
  res.json({ status: 'completed', incentive: INCENTIVE_RS });
});

mongoose.connect(process.env.MONGO_URI).then(() => server.listen(process.env.PORT || 3000, () => console.log('APSI backend up')));
